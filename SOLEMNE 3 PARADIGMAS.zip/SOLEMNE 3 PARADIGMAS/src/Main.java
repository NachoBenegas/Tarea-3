import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Restaurante restaurante = new Restaurante();
        Scanner sc = new Scanner(System.in);
        int opcion;

        System.out.println("BIENVENIDO A \"MI MEJOR COMIDA\"");
        System.out.println("--------------------------------------");

        do {
            System.out.println("\n1. Calcular calorías de un menú específico");
            System.out.println("2. Mostrar combinaciones bajas en calorías");
            System.out.println("3. Salir");
            System.out.print("\nSeleccione una opción (1-3): ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese una entrada: ");
                    String entrada = sc.nextLine();
                    System.out.print("Ingrese un plato principal: ");
                    String principal = sc.nextLine();
                    System.out.print("Ingrese un postre: ");
                    String postre = sc.nextLine();

                    var e = restaurante.buscarPlato(entrada);
                    var p = restaurante.buscarPlato(principal);
                    var po = restaurante.buscarPlato(postre);

                    if (e.isEmpty() || p.isEmpty() || po.isEmpty()) {
                        System.out.println("Error: Uno o más platos no existen. Intente nuevamente.");
                    } else {
                        int total = restaurante.calcularTotal(e.get(), p.get(), po.get());
                        System.out.println("Total de calorías: " + total + " calorías");
                    }
                    break;

                case 2:
                    System.out.print("Ingrese el máximo de calorías deseado: ");
                    int limite = sc.nextInt();
                    sc.nextLine(); // limpiar buffer
                    System.out.println("\n--- MENÚS BAJOS EN CALORÍAS ---");
                    restaurante.mostrarCombinacionesBajasEnCalorias(limite);
                    break;

                case 3:
                    System.out.println("¡Gracias por usar el sistema!");
                    break;

                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }

        } while (opcion != 3);
    }
}
