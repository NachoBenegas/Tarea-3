
===============================
SISTEMA DE GESTIÓN DE CALORÍAS "Mi Mejor Comida"
ESTUDIANTES:    Martín Araya, Ignacio Benegas, Carlos Gonzales
FECHA: 22 de Junio 2025
===============================

1. DESCRIPCIÓN DEL PROYECTO
-------------------------------
Este sistema interactivo, desarrollado en Java utilizando programación funcional, permite calcular y
sugerir combinaciones de menús saludables para los clientes del restaurante ficticio "Mi Mejor Comida".
El sistema está basado en una base de datos interna de platos, organizados en tres categorías: entradas,
platos principales y postres, cada uno con sus respectivas calorías.

El programa funciona por consola y permite dos funcionalidades clave:
    • Calcular las calorías totales de un menú personalizado (entrada + principal + postre).
    • Mostrar todas las combinaciones posibles de platos que no superen un límite calórico dado por el usuario.

2. ALCANCES Y RESTRICCIONES
-------------------------------
• Lenguaje: Java
• Enfoque: Programación funcional
• Interfaz de usuario por consola
• Validación de nombres de platos ingresados por el usuario
• Cálculo automático de combinaciones válidas bajo un límite de calorías
• Sin almacenamiento persistente

3. INSTRUCCIONES DE EJECUCIÓN (INTELLIJ IDEA)
-------------------------------

3.1 Requisitos Previos
    - Java Development Kit (JDK) 8 o superior
    - IntelliJ IDEA (Community o Ultimate)

3.2 Importar el Proyecto en IntelliJ

    - Abre IntelliJ IDEA
    - Haz clic en "Open" y selecciona la carpeta raíz del proyecto
    - IntelliJ detectará automáticamente el archivo

3.3 Ejecutar la Aplicación

    1. Abre la clase:
        Main.java
    2. Haz clic derecho sobre el archivo y selecciona:
        Run 'Main.main()'

    → Esto iniciará el sistema por consola.

4. FUNCIONALIDADES
-------------------------------
• Ingreso de platos para calcular calorías totales:
    - Entrada + Principal + Postre
    - Resultado en calorías del menú elegido

• Generación de combinaciones saludables bajo cierto límite calórico:
    - El usuario ingresa un máximo de calorías (ej: 500)
    - El sistema muestra todas las combinaciones posibles que no superen ese valor

• Validación de entrada de texto:
    - Si el nombre de un plato no es válido, se notifica al usuario

5. EJEMPLO DE EJECUCIÓN
-------------------------------

BIENVENIDO A "MI MEJOR COMIDA"
--------------------------------------

1. Calcular calorías de un menú específico
2. Mostrar combinaciones bajas en calorías
3. Salir

Seleccione una opción (1-3): 2

Ingrese el máximo de calorías deseado: 500

--- MENÚS BAJOS EN CALORÍAS ---

* Entrada: Gazpacho (150 cal)
  Principal: Trucha (160 cal)
  Postre: Naranja (50 cal)
  TOTAL: 360 calorías

===============================
FIN DEL DOCUMENTO
===============================
